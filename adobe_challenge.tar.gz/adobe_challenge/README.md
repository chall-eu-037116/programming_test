
Included are the solutions to three Project Euler Problems:

    Problem  54: "Poker hands"  https://projecteuler.net/problem=54
    Problem 301: "Nim"          https://projecteuler.net/problem=301
    Problem 323: "Bitwise-OR"   https://projecteuler.net/problem=323

I chose problem 54 as it was complex enough to demonstrate some software
design and development skills, including object oriented programming and
unit testing. I first modeled a playing card and poker hand which can
be adapted for other card games or poker variants in the future. To that
end, I designed the Card class to be generic, but did not spend time to
make PokerHand generic. For comparing poker hands, I considered a few
methods, including assigning a score to each hand before coming across a
straightforward algorithm for comparing poker hands at
http://nsayer.blogspot.com/2007/07/algorithm-for-evaluating-poker-hands.html.

I chose problem 301 because Nim looked like an interesting game to learn
and I like to play games. I researched the game including an online version
of the game at http://www.archimedes-lab.org/How_to_Solve/Win_at_Nim.html. My
initial implementation based on xor proved extremely slow to execute at over
12 minutes. I then found an algorithm based on the Fibonacci series at
https://github.com/nayuki/Project-Euler-solutions/blob/master/python/p301.py.

I chose problem 323 as bit manipulations are relevant to programming in general
and straightforward enough to be completed relatively quickly. I found a good
discussion of the probability behind the algorithm at
http://math.stackexchange.com/questions/101673/flaw-in-expected-value-solving-logic-project-euler-323.

I spent the most time on problem 54 which was my intention. I wanted to spend
the most time on typical software development tasks. Overall, I spent about
15 hours on all of the problems.


Program Output
--------------
$./euler_54.py
Euler 54: Player 1 wins 376 times. Running time: 75.290 ms.
$./euler_301.py
Euler 301: Player 1 loses 2178309 times. Running time: 1832.022 ms.
$./euler_323.py
Euler 323: Expected 6.3551758451 iterations before all bits are 1. Running time: 0.054 ms.

$python --version    Python 2.7.10
