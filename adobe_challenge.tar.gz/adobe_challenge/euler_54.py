#!/usr/bin/python
import time


class Card(object):
    ranks = '23456789TJQKA'
    suits = {'C', 'D', 'S', 'H'}

    def __init__(self, rank, suit):
        """
        Creates a card from a rank and a suit.

        The rank may be an integer or a string.
        The suit must be one of: 'C', 'D', 'S', 'H'.
        A cards value is its position in the rank sequence.
        """
        if suit not in Card.suits:
            raise ValueError("Card suit must be one of '%s.'" % ''.join(Card.suits))
        self.suit = suit

        if not isinstance(rank, basestring):
            rank = str(rank)
        rank_position = Card.ranks.find(rank)
        if rank == '' or rank_position < 0:
            raise ValueError("Card value must be one of '%s.'" % Card.ranks)
        self.value = rank_position

    @classmethod
    def get_value(cls, rank):
        """
        Returns the numeric value for a card rank.
        """
        return cls.ranks.find(rank)

    @classmethod
    def from_string(cls, card_definition):
        """
        Create a Card object from a string of the
        form '3C' indicating the three of clubs.
        """
        if not card_definition or len(card_definition) != 2:
            raise ValueError("A card is a 2 character string such as '3C'.")
        return cls(card_definition[0], card_definition[1])


class PokerHand(object):
    """
    A PokerHand is made up of 5 Cards.

    PokerHands can be compared using the PokerHand.compare() method.
    The general approach to comparing hands is based on:
        http://nsayer.blogspot.com/2007/07/algorithm-for-evaluating-poker-hands.html

    Card 'groups' represents card value groups sorted by their occurrences:
        '8C TS KC 8H 4S' ==> [(6, 2), (11, 1), (8, 1), (2, 1)]
    """
    def __init__(self, cards):
        if not cards or len(cards) != 5:
            raise ValueError("A Hand must must have 5 Cards.")

        self.values = [c.value for c in cards]
        self.suits = set([c.suit for c in cards])

        # Group like cards and sort by count and value descending
        self.groups = [(n, self.values.count(n)) for n in set(self.values)]
        self.groups.sort(key=lambda c: (c[1], c[0]), reverse=True)

        # Special case for A-5 straight
        if (len(self.groups) == 5 and self.groups[0][0] == len(Card.ranks) - 1 and
                self.groups[1][0] == 3 and self.groups[4][0] == 0):
            self.groups = [(3, 1), (2, 1), (1, 1), (0, 1), (-1, 1)]

        self.is_straight = len(self.groups) == 5 and self.groups[0][0] - self.groups[4][0] == 4

        self.is_flush = len(self.suits) == 1
        self.high_card = self.groups[0][0]

    @classmethod
    def five_card_from_string(cls, hand_definition):
        """
        Create a Hand object from a string of 5 Card
        representations such as '8C TS KC 9H 4S'.
        """
        if not hand_definition or len(hand_definition) != 14:
            raise ValueError("A Hand is 5 space separated card pairs such as '8C TS KC 9H 4S'.")
        return PokerHand([Card.from_string(c) for c in hand_definition.split()])

    @classmethod
    def compare(cls, h1, h2):
        """
        Compares two poker hands h1 and h2.
        Returns:

             > 0 if h1 wins
               0 if h1 and h2 are equal
             < 0 if h2 wins
        """

        # Straight Flush
        if h1.is_straight and h1.is_flush:
            if h2.is_straight and h2.is_flush:
                return h1.groups[0][0] - h2.groups[0][0]
            else:
                return 1
        if h2.is_straight and h2.is_flush:
            return -1

        # 4 of a kind or full house
        if len(h1.groups) == 2:
            if len(h2.groups) == 2:
                # Check if both hands are same type, else winner is hand with 4 of a kind
                if h1.groups[0][1] == h2.groups[0][1]:
                    # Compare high card in larger group, else compare smaller group
                    if h1.groups[0][0] == h2.groups[0][0]:
                        return h1.groups[1][0] - h2.groups[1][0]
                    else:
                        return h1.groups[0][0] - h2.groups[0][0]
                else:
                    return h1.groups[0][1] - h2.groups[0][1]
            else:
                return 1
        if len(h2.groups) == 2:
            return -1

        # Flush
        if h1.is_flush:
            if h2.is_flush:
                # Check all cards for tie-breaker by higher card
                for i in range(5):
                    if h1.groups[i][0] != h2.groups[i][0]:
                        return h1.groups[i][0] - h2.groups[i][0]
                return 0
            else:
                return 1
        if h2.is_flush:
            return -1

         # Straight
        if h1.is_straight:
            if h2.is_straight:
                # High card wins
                return h1.groups[0][0] - h2.groups[0][0]
            else:
                return 1
        if h2.is_straight:
            return -1

        # Both hands are either 3 of a kind, 2 pair, 1 pair or high card
        # The fewest groupings wins (2 pair beats 1 pair, etc.)
        if len(h1.groups) != len(h2.groups):
            return len(h2.groups) - len(h1.groups)

        # The hands are of the same groupings - same type or 3 of a kind and 2 pair
        for i in range(len(h1.groups)):
            if h1.groups[i][1] != h2.groups[i][1]:
                return h1.groups[i][1] - h2.groups[i][1]
            # Check for high card
            if h1.groups[i][0] != h2.groups[i][0]:
                return h1.groups[i][0] - h2.groups[i][0]
        return 0


def euler_54():
    """
    Solution to project Euler problem 54: https://projecteuler.net/problem=54

    Reads hands from file p054_poker.txt in the current directory.
    Each line contains 2 5 card hands for player 1 followed by player 2 as in:
        '8C TS KC 9H 4S 7D 2S 5D 3S AC'

    Returns the number of hands won by player 1.
    """
    player1_wins = 0
    with open('./p054_poker.txt') as f:
        for line in f:
            hand1 = PokerHand.five_card_from_string(line[:14])
            hand2 = PokerHand.five_card_from_string(line[15:-1])
            if PokerHand.compare(hand1, hand2) > 0:
                player1_wins += 1
    return player1_wins


if __name__ == '__main__':

    start_time = time.time()
    wins = euler_54()
    elapsed_time_ms = (time.time() - start_time) * 1000.0
    print "Euler 54: Player 1 wins %d times. Running time: %0.3f ms." % (wins, elapsed_time_ms)
