#!/usr/bin/python
import unittest
from euler_301 import fibonacci


class TestNim(unittest.TestCase):

    def test_fibonacci_0(self):
        self.assertEquals(0, fibonacci(0))

    def test_fibonacci_1(self):
        self.assertEquals(1, fibonacci(1))

    def test_fibonacci_2(self):
        self.assertEquals(1, fibonacci(2))

    def test_fibonacci_3(self):
        self.assertEquals(2, fibonacci(3))

    def test_fibonacci_4(self):
        self.assertEquals(3, fibonacci(4))

    def test_fibonacci_5(self):
        self.assertEquals(5, fibonacci(5))

    def test_fibonacci_negative(self):
        with self.assertRaises(ValueError):
            fibonacci(-1)


if __name__ == '__main__':
    unittest.main()
