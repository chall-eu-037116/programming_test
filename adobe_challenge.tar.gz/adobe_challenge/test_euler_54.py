#!/usr/bin/python
import unittest
from euler_54 import Card, PokerHand


class TestCard(unittest.TestCase):

    def test_create(self):
        for i, rank in enumerate(Card.ranks):
            for suit in Card.suits:
                c = Card(rank, suit)
                self.assertEqual(c.suit, suit)
                self.assertEqual(c.value, i)

    def test_create_with_int_rank(self):
        for i, rank in enumerate(Card.ranks):
            try:
                rank = int(rank)
            except ValueError:
                # Only test integer ranks
                continue
            c = Card(rank, 'D')
            self.assertEqual(c.suit, 'D')
            self.assertEqual(c.value, i)

    def test_invalid_suit(self):
        with self.assertRaises(ValueError):
            Card(suit='Z', rank='7')

    def test_invalid_rank(self):
        with self.assertRaises(ValueError):
            Card(suit='D', rank='1')

    def test_empty_suit(self):
        with self.assertRaises(ValueError):
            Card(suit='', rank='7')

    def test_empty_rank(self):
        with self.assertRaises(ValueError):
            Card(suit='D', rank='')

    def test_none_suit(self):
        with self.assertRaises(ValueError):
            Card(suit=None, rank='7')

    def test_none_rank(self):
        with self.assertRaises(ValueError):
            Card(suit='D', rank=None)

    def test_create_from_string(self):
        for i, rank in enumerate(Card.ranks):
            for suit in Card.suits:
                c = Card.from_string('%s%s' % (rank, suit))
                self.assertEqual(c.suit, suit)
                self.assertEqual(c.value, i)

    def test_from_string_invalid_suit(self):
        with self.assertRaises(ValueError):
            Card.from_string('2Z')

    def test_from_string_invalid_rank(self):
        with self.assertRaises(ValueError):
            Card.from_string('ZD')

    def test_from_string_empty_string(self):
        with self.assertRaises(ValueError):
            Card.from_string('')

    def test_from_string_none(self):
        with self.assertRaises(ValueError):
            Card.from_string(None)

    def test_from_string_too_many_chars(self):
        with self.assertRaises(ValueError):
            Card.from_string('2D3')


class TestPokerHand(unittest.TestCase):

    # Test poker hands in winning order
    test_hands = [
        # straight flushes
        'TH JH QH KH AH',
        'AC 2C 3C 4C 5C',
        # 4 of a kind
        'AH AD AC AH 8H',
        '5H 5D 5C 5H TH',
        # full house
        'TH TD TC AH AD',
        '5H 5D 5C AC AS',
        # flush
        '3H 4H 8H 9H AH',
        '2D 5D 6D 8D AD',
        '6C 8C TC JC KC',
        # straight
        '5H 6D 7H 8C 9S',
        'AH 2D 3H 4C 5S',
        # 3 of a kind
        'TH TD TC AH 6D',
        '5H 5D 5C 8H JD',
        # 2 pairs
        'TH TD 6C 6H AD',
        'TC TS 6D 6S 9D',
        'TC TS 3D 3S 9D',
        '9H 9D 5C 5H AD',
        # 1 pair
        'AH AD TC 8H 5D',
        'AC AS TD 6S 2D',
        'AC AS 8D 7S 4D',
        # high card
        'AC TS 8D 6S 4D',
        'AS TC 6D 4S 2D',
        'KH QD 9C 7H 5D',
    ]

    def test_create_from_string(self):
        hand_string = '8C TS KC 8H 4S'
        hand = PokerHand.five_card_from_string(hand_string)
        self.assertEqual(set(hand.values), set([Card.get_value(n) for n, _ in hand_string.split()]))
        self.assertEqual(hand.suits, {'C', 'S', 'H'})
        self.assertFalse(hand.is_straight)
        self.assertFalse(hand.is_flush)

        self.assertEqual(hand.groups, [
            (Card.get_value('8'), 2),
            (Card.get_value('K'), 1),
            (Card.get_value('T'), 1),
            (Card.get_value('4'), 1)
        ])

    def test_create_from_string_none(self):
        with self.assertRaises(ValueError):
            PokerHand.five_card_from_string(None)

    def test_create_from_string_none_empty(self):
        with self.assertRaises(ValueError):
            PokerHand.five_card_from_string('')

    def test_create_from_string_too_few(self):
        with self.assertRaises(ValueError):
            PokerHand.five_card_from_string('8C TS KC 8H')

    def test_create_from_string_too_many(self):
        with self.assertRaises(ValueError):
            PokerHand.five_card_from_string('8C TS KC 8H 4S 7H')

    def test_compare(self):
        """
        Iterate through ranked hands. Every hand should beat
        all the lower ranked hands.
        """
        for i, test_hand in enumerate(TestPokerHand.test_hands[:-1]):
            h1 = PokerHand.five_card_from_string(test_hand)
            for j in range(i + 1, len(TestPokerHand.test_hands)):
                h2 = PokerHand.five_card_from_string(TestPokerHand.test_hands[j])
                self.assertGreater(PokerHand.compare(h1, h2), 0)


if __name__ == '__main__':
    unittest.main()