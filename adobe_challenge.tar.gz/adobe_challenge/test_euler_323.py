#!/usr/bin/python
import unittest
from euler_323 import random_or


class TestNim(unittest.TestCase):

    def test_random_or_1(self):
        self.assertEquals(2.0, random_or(1))

    def test_random_or_6(self):
        self.assertEquals(6.355175845103934, random_or(32))

    def test_random_or_0(self):
        with self.assertRaises(ValueError):
            random_or(0)

    def test_random_or_negative(self):
        with self.assertRaises(ValueError):
            random_or(-1)


if __name__ == '__main__':
    unittest.main()
