#!/usr/bin/python
import time


def random_or(num_bits):
    """
    Returns the expected index in a sequence of iteratively OR-ing random
    'num_bits' bit integers together until the resulting integer bits
    are all flipped to 1.

    The returned value will be a floating point approximation with at least
    10 decimal place precision.
    """

    if num_bits < 1:
        raise ValueError("'num_bits' must be >= 1.")

    expected_iterations = 1
    approx_flipped = 0.5
    prev_approx_flipped = 0

    while True:
        additional_iterations = 1 - (approx_flipped**num_bits)
        # No longer adding amounts significant to 10 decimal place result
        if additional_iterations < 1e-20:
            break
        expected_iterations += additional_iterations
        prev_approx_flipped, approx_flipped = \
            approx_flipped, approx_flipped + (approx_flipped - prev_approx_flipped) * 0.5

    return expected_iterations


def euler_323():
    """
    Solution to project Euler problem 323: https://projecteuler.net/problem=323

    Returns an approximation of the expected index at which the result of random
    32-bit integers OR-ed together iteratively has a 100% chance of being all 1s.

    For background on the cumulative probability algorithm used:
        http://math.stackexchange.com/questions/101673/flaw-in-expected-value-solving-logic-project-euler-323
    """
    return random_or(32)


if __name__ == '__main__':
    start_time = time.time()
    expected_index = euler_323()
    elapsed_time_ms = (time.time() - start_time) * 1000.0
    print "Euler 323: Expected %.10f iterations before all bits are 1. Running time: %0.3f ms." \
          % (expected_index, elapsed_time_ms)
