#!/usr/bin/python
import time


# This is not used, but was my original xor approach to Euler 301. This method
# took 12 minutes. I found an alternative algorithm based on Fibonacci.
def nim_sum(heap1, heap2, heap3):
    """
    Returns the nim sum, the result applying xor the the sizes of the
    heaps in the game. In nim, assuming both players play optimally,
    a player with a nim_sum of 0 will lose.
    """
    if heap1 == heap2 == heap3 == 0:
        raise ValueError('Nim heaps must contain at least one stone.')
    return heap1 ^ heap2 ^ heap3


def fibonacci(n):
    """
    Returns the nth integer in the Fibonacci series.
    """
    if n < 0:
        raise ValueError("Fibonacci term must be >= 0.")

    if n == 0 or n == 1:
        return n

    return fibonacci(n - 1) + fibonacci(n - 2)


def euler_301(m):
    """
    Solution to project Euler problem 301: https://projecteuler.net/problem=301

    Returns player 1 losses for all possible heap sizes:
        (n, 2n, 3n) where 0 < n <= 2**m

    For background on the use of Fibonacci series to solve this:
        https://github.com/nayuki/Project-Euler-solutions/blob/master/python/p301.py
    """
    return fibonacci(m)


if __name__ == '__main__':
    start_time = time.time()
    player1_losses = euler_301(32)
    elapsed_time_ms = (time.time() - start_time) * 1000.0
    print "Euler 301: Player 1 loses %d times. Running time: %0.3f ms." % (player1_losses, elapsed_time_ms)
